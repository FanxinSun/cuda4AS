// Generated device split; source semantics are imported into cuda4AS IR.
struct dim3 { unsigned int x; unsigned int y; unsigned int z; };
extern "C" __device__ dim3 blockIdx;
extern "C" __device__ dim3 blockDim;
extern "C" __device__ dim3 threadIdx;
__global__ void vector_add(const float *a, const float *b, float *c, int n) {
  int i = ((blockIdx.x * blockDim.x) + threadIdx.x);
  if ((i < n)) {
    c[i] = (a[i] + b[i]);
  }
}
