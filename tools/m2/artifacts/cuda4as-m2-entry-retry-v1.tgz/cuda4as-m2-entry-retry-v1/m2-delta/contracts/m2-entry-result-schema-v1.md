# cuda4AS M2 entry retry result contract v1

This contract records one bounded native retry of the inventory-bound M1
package. The retry may apply exactly one candidate-owned patch identified by
`candidate/patch-binding.json`; it does not change application sources,
fixtures, expected outputs, build options, or the VF64 archive.

The returned archive has schema `cuda4as-m2-native-return-v1` and includes the
base M1 `PACKAGE-MANIFEST.sha256`, the complete `m2-delta` manifest and patch
binding under `package/`, facts, ordered case-stage events, assertions, logs,
and exact output files. The analyzer must reject a missing or mismatched base
artifact, inventory binding, delta manifest, patch identity, clean or patched
tree identity, fixture hash, Apple-GPU provenance, fallback/reduced precision,
or exact output.

The three required cases remain in this order:

1. `oracle.vector_add` (`source=generic_nvvm`)
2. `integration.minimal_cmake_cuda` (`source=generic_ptx`)
3. `integration.multi_tu_device_link` (`source=generic_ptx`)

`PASS_GPU` requires every required stage for that case, an inventoried Apple
GPU name, successful launch and completion, exact expected bytes and SHA-256,
unchanged fixture inputs before and after the run, and no CPU/fallback or
reduced-precision provenance. A build or environment failure is preserved as
evidence; no case is relabeled as executed. A pass is evidence only for this
patched candidate and these fixtures on the bound Mac.
