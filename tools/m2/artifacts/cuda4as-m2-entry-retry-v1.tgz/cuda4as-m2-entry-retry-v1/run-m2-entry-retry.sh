#!/bin/bash
# Prepare a private M1 package copy, attach the M2 delta, and run one bounded
# candidate-patch retry. No download, installation, sudo, or host modification.

set -u
umask 077

DELTA_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
BASE_ARTIFACT="${CUDA4AS_M1_ARTIFACT:-${HOME}/Downloads/cuda4as-m1-native-feasibility-v1.tgz}"
TASK_ROOT="${CUDA4AS_M2_TASK_ROOT:-${HOME}/cuda4as-m2/entry-v1}"
START_UTC="$(/bin/date -u '+%Y%m%dT%H%M%SZ')"
BASE_SHA256="dbb390b4f470b8f286ccb65a2b8565a235e749d9122c16e8e92ade96e0099bc7"
BASE_BYTES=8549223

printf '%s\n' "cuda4AS M2 entry retry: delta=${DELTA_ROOT}"
printf '%s\n' "cuda4AS M2 entry retry: base=${BASE_ARTIFACT}"
if [ ! -f "${BASE_ARTIFACT}" ]; then
  printf 'error: M1 base artifact is missing: %s\n' "${BASE_ARTIFACT}" >&2
  exit 2
fi

if ! (cd "${DELTA_ROOT}" && /usr/bin/shasum -a 256 -c PACKAGE-MANIFEST.sha256) \
    >"${DELTA_ROOT}/delta-manifest-check-${START_UTC}.stdout.txt" \
    2>"${DELTA_ROOT}/delta-manifest-check-${START_UTC}.stderr.txt"; then
  printf 'error: M2 delta manifest failed; no base extraction attempted\n' >&2
  exit 3
fi

actual_bytes="$(/usr/bin/wc -c <"${BASE_ARTIFACT}" | /usr/bin/tr -d '[:space:]')"
actual_sha256="$(/usr/bin/shasum -a 256 "${BASE_ARTIFACT}" | /usr/bin/awk '{print $1}')"
if [ "${actual_bytes}" != "${BASE_BYTES}" ] || [ "${actual_sha256}" != "${BASE_SHA256}" ]; then
  printf 'error: base M1 artifact identity mismatch\n' >&2
  printf 'expected bytes=%s sha256=%s\n' "${BASE_BYTES}" "${BASE_SHA256}" >&2
  printf 'observed bytes=%s sha256=%s\n' "${actual_bytes}" "${actual_sha256}" >&2
  exit 4
fi

BASE_STAGE="${TASK_ROOT}/base/${START_UTC}"
BASE_UNPACK="${BASE_STAGE}/unpacked"
mkdir -p "${BASE_UNPACK}"

# The base is a repository-produced archive with a single known top-level
# directory. Reject unsafe names before extraction and require that root.
ARCHIVE_LIST="${BASE_STAGE}/base-archive-list.txt"
if ! /usr/bin/tar -tzf "${BASE_ARTIFACT}" >"${ARCHIVE_LIST}" 2>"${BASE_STAGE}/base-archive-list.stderr.txt"; then
  printf 'error: cannot read base archive\n' >&2
  exit 5
fi
if /usr/bin/awk '
  $0 ~ /^\// || $0 ~ /(^|\/)\.\.($|\/)/ || $0 !~ /^cuda4as-m1-native-feasibility-v1\// { bad=1 }
  END { exit bad ? 0 : 1 }
' "${ARCHIVE_LIST}"; then
  printf 'error: base archive has an unsafe or unexpected member path\n' >&2
  exit 6
fi
if ! /usr/bin/tar -xzf "${BASE_ARTIFACT}" -C "${BASE_UNPACK}"; then
  printf 'error: base archive extraction failed\n' >&2
  exit 7
fi

BASE_ROOT="${BASE_UNPACK}/cuda4as-m1-native-feasibility-v1"
if [ ! -d "${BASE_ROOT}" ] || [ ! -f "${BASE_ROOT}/PACKAGE-MANIFEST.sha256" ]; then
  printf 'error: expected M1 package root was not extracted\n' >&2
  exit 8
fi

/bin/cp -R "${DELTA_ROOT}/m2-delta" "${BASE_ROOT}/m2-delta"
/bin/cp "${DELTA_ROOT}/m2-delta/run-m2-native-feasibility.sh" \
  "${BASE_ROOT}/run-m2-native-feasibility.sh"
/bin/chmod 755 "${BASE_ROOT}/run-m2-native-feasibility.sh"

printf '%s\n' "base artifact verified: ${BASE_BYTES} bytes ${BASE_SHA256}"
printf '%s\n' "running the three unchanged M1 cases with exactly one candidate patch"
set +e
(
  cd "${BASE_ROOT}" || exit 9
  ./run-m2-native-feasibility.sh
) | /usr/bin/tee "${DELTA_ROOT}/native-run-${START_UTC}.console.txt"
runner_status=${PIPESTATUS[0]}
set -e

RETURN_ARCHIVE="$(find "${BASE_ROOT}/returns" -maxdepth 1 -type f \
  -name 'cuda4as-m2-native-return-*.tgz' -print 2>/dev/null | sort | tail -n 1)"
if [ -n "${RETURN_ARCHIVE}" ]; then
  return_bytes="$(/usr/bin/wc -c <"${RETURN_ARCHIVE}" | /usr/bin/tr -d '[:space:]')"
  return_sha256="$(/usr/bin/shasum -a 256 "${RETURN_ARCHIVE}" | /usr/bin/awk '{print $1}')"
  printf '%s\n' "RETURN_ARCHIVE=${RETURN_ARCHIVE}"
  printf '%s\n' "RETURN_BYTES=${return_bytes}"
  printf '%s\n' "RETURN_SHA256=${return_sha256}"
else
  printf '%s\n' 'RETURN_ARCHIVE=missing' >&2
fi
exit "${runner_status}"
