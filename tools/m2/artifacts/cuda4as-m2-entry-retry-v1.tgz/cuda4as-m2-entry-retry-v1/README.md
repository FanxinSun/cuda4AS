# cuda4AS M2 entry retry delta v1

This is a small delta package for the already tracked and inventory-bound
`cuda4as-m1-native-feasibility-v1.tgz`. It applies exactly one candidate-owned
source correction (`#include <array>` in
`compiler/ptx/src/lower_to_llvm.cpp`) in a private extracted copy, then runs
the three unchanged M1 cases with the same Release, `sm_86`, `ieee64`,
registration-on, binary-shim-off configuration.

The delta performs no network operation, installation, update, `sudo`, or
change outside its task directory. It refuses a base package whose byte count
or SHA-256 differs from the bound M1 artifact. It verifies both the clean and
patched 1,065-file candidate identities, records the patch and all stage
evidence, and returns a new archive with schema
`cuda4as-m2-native-return-v1`. A return is not a cuda4AS classification until
the repository-side analyzer validates its complete manifests, inventory and
GPU provenance.

## User-run commands

Place this delta and the existing base package in a local Mac directory. The
base package must be exactly:

```
cuda4as-m1-native-feasibility-v1.tgz
8549223 bytes
dbb390b4f470b8f286ccb65a2b8565a235e749d9122c16e8e92ade96e0099bc7
```

Extract the delta, then run from its extracted directory:

```
DELTA_DIR="$HOME/Downloads/cuda4as-m2-entry-retry-v1"
BASE_ARTIFACT="$HOME/Downloads/cuda4as-m1-native-feasibility-v1.tgz"
cd "$DELTA_DIR"
CUDA4AS_M1_ARTIFACT="$BASE_ARTIFACT" \
CUDA4AS_M2_TASK_ROOT="$HOME/cuda4as-m2/entry-v1" \
./run-m2-entry-retry.sh | tee native-run.console.txt
```

The expected existing Mac prerequisites are the previously bound inventory:
arm64 Apple M1 Pro / MacBookPro18,3, macOS 14.4 build 23E214, Xcode 15.2
build 15C500b, SDK 14.2, CMake 4.3.3, Ninja 1.12.1, Homebrew LLVM 23.1.0,
LZ4 1.10.0, and Zstd 1.5.7. No new installation is authorized by this drop.

The run is bounded to the existing 5 GiB minimum free-space gate, at most four
parallel jobs, and the existing task-local build/output directories. Stop the
run if it asks for a download, installation, `sudo`, a second patch, a changed
fixture or option, or more than 20 GiB of task-local space. A normal build is
expected to take minutes; stop and return evidence if it exceeds 30 minutes.

The script prints one return path, byte count, and SHA-256 even on a controlled
failure or environment gap. Return that one archive unchanged to:

```
/home/rog/business/YFCE/cuda4AS/RESULTS/m2/incoming/cuda4as-m2-native-return-<UTC>.tgz
```

The repository-side validation will classify all three cases independently.
One valid Apple-GPU pass is sufficient for the entry gate; a build failure,
environment gap, fallback, reduced precision, output mismatch, or unrun case
remains visible and leads to the preselected Native AOT Core v1 architecture
route if no validated pass exists.
