# cuda4as-m2a-native-aot-vector-add-v1

This is the user-operated M2A Native AOT Core v1 drop. It performs no network, install, update, sudo, or CPU fallback. The runner writes all evidence beneath this extracted directory and returns one archive.

Bound machine: MacBookPro18,3 / Apple M1 Pro / 14.4 (23E214); Xcode Xcode 15.2 Build version 15C500b; SDK 14.2; LLVM 23.1.0.

The package contains the unchanged oracle source and header. Do not edit them.
